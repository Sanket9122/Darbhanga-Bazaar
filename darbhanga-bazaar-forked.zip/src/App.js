import "./styles.css";
import Navbar from "./component/Navbar";
import Component1 from "./routes/component1";
import Component2 from "./routes/component2";
export default function App() {
  return (
    <>
      <Navbar />
      <Component1 />
      <Component2 />
    </>
  );
}
