export const Menuitems = [
  {
    title: "Home",
    url: "/",
    cName: "nav-links",
    icon: "fa-solid fa-house",
  },
  {
    title: "Contact",
    url: "/",
    cName: "nav-links",
    icon: "fa-solid fa-address book",
  },
  {
    title: "Favorites",
    url: "/",
    cName: "nav-links",
    icon: "fa-solid fa-star",
  },
];
