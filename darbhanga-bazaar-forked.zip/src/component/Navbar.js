import { Component } from "react";
import "./Navbar.css";
import { Menuitems } from "./Menuitems";
import { Link } from "react-router-dom";
class Navbar extends Component {
  state = {
    clicked: false,
  };
  handleclick = () => {
    this.setState({ clicked: !this.state.clicked });
  };
  render() {
    return (
      <nav className="Navbar-items">
        <a href="index.html">
          <h3>
            Darbhanga
            <p>Bazaar</p>
          </h3>
        </a>
        <div className="menu-icon" onClick={this.handleclick}>
          <i
            className={this.state.clicked ? "fas fa-times" : "fas fa-bars"}
          ></i>
        </div>
        <ul className={this.state.clicked ? "nav-menu active" : "nav-menu"}>
          {Menuitems.map((item, index) => {
            return (
              <li key={index}>
                <a href="/" className={item.cName}>
                  <i className={item.icon}></i>
                  <span>{item.title}</span>
                </a>
              </li>
            );
          })}
          <input type="text" placeholder="Serach" />
        </ul>
      </nav>
    );
  }
}
export default Navbar;
