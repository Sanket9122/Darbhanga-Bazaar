import { Component } from "react";
import "./component1.css"
class component1 extends Component {
  render() {
    return (
      <main id="blog-container" className="obj-width">
        <div className="blog-card">
          <h3>Food</h3>
        </div>
        <div className="blog-card">
          <h3>Clothes</h3>
        </div>
        <div className="blog-card">
          <h3>Shoes</h3>
        </div>
        <div className="blog-card">
          <h3>Electronics</h3>
        </div>
        <div className="blog-card">
          <h3>Vegetables</h3>
        </div>
        <div className="blog-card">
          <h3>Grocery</h3>
        </div>
      </main>
    );
  }
}
export default component1;
