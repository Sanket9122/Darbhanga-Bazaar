import { Component } from "react";
import "./component2.css";
class component2 extends Component {
  render() {
    return (
      <main id="Blog-container" className="Obj-width">
        <div className="Blog-card">
          <h1>SHOP</h1>
          <h3>DARBHANGA</h3>
          <p>
            Discover the diversity of Darbhanga's offerings, all at your
            fingertips.Shop seamlessly from any store in town, right from
            comfort of your home!
          </p>
        </div>
      </main>
    );
  }
}
export default component2;
